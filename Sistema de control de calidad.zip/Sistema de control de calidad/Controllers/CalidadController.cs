using Microsoft.AspNetCore.Mvc;
using Sistema_de_control_de_clidad.Models;
using Sistema_de_control_de_clidad.Models.Repositorios;
using Sistema_de_control_de_clidad.Models.ViewModels;

namespace Sistema_de_control_de_clidad.Controllers
{
    public class CalidadController : Controller
    {
        private readonly CalidadRepositorio _repositorio;

        public CalidadController(CalidadRepositorio repositorio)
        {
            _repositorio = repositorio;
        }

        public IActionResult Index(string? busqueda)
        {
            var lista = _repositorio.Buscar(busqueda);
            ViewBag.Busqueda = busqueda;
            CargarViewBagsDeApoyo();
            return View(lista);
        }

        public IActionResult Filtrar(string? producto, string? inspector, string? resultado)
        {
            var lista = _repositorio.Filtrar(producto, inspector, resultado);
            ViewBag.ProductoSeleccionado = producto;
            ViewBag.InspectorSeleccionado = inspector;
            ViewBag.ResultadoSeleccionado = resultado;
            CargarViewBagsDeApoyo();
            return View("Index", lista);
        }

        public IActionResult Panelgeneral()
        {
            var todas = _repositorio.ObtenerTodas();
            int aprobadas = todas.Count(i => i.Resultado == "Aprobado");
            int rechazadas = todas.Count(i => i.Resultado == "Rechazado");

            var vm = new DashboardCalidaModel
            {
                TotalInspecciones = todas.Count,
                TotalAprobadas = aprobadas,
                TotalRechazadas = rechazadas,
                TasaAprobacionGlobal = todas.Count == 0 ? 0 : Math.Round((double)aprobadas / todas.Count * 100, 2),
                PromedioDefectos = todas.Count == 0 ? 0 : Math.Round(todas.Average(i => _repositorio.CalcularPorcentajeDefectos(i)), 2),
                InspectorLider = todas
                    .GroupBy(i => i.Inspector)
                    .OrderByDescending(g => g.Count())
                    .Select(g => g.Key)
                    .FirstOrDefault() ?? "N/A",
                ProductoFocoAlerta = todas
                    .GroupBy(i => i.Producto)
                    .OrderByDescending(g => g.Average(i => _repositorio.CalcularPorcentajeDefectos(i)))
                    .Select(g => g.Key)
                    .FirstOrDefault() ?? "N/A",
                UltimasInspecciones = todas.Take(5).ToList(),
                FechaServidor = DateTime.Now
            };

            ViewData["Aprobadas"] = aprobadas;
            ViewData["Rechazadas"] = rechazadas;
            ViewData["TotalInspecciones"] = vm.TotalInspecciones;
            ViewData["PromedioDefectos"] = vm.PromedioDefectos;
            ViewData["FechaServidor"] = vm.FechaServidor;

            return View(vm);
        }

        public IActionResult Detalles(int id)
        {
            var inspeccion = _repositorio.ObtenerPorId(id);
            if (inspeccion is null) return NotFound();

            double porcentaje = _repositorio.CalcularPorcentajeDefectos(inspeccion);
            var vm = new InspeccionModel
            {
                Inspeccion = inspeccion,
                PorcentajeDefectos = porcentaje,
                NivelCalidad = _repositorio.ObtenerNivelCalidad(porcentaje)
            };
            return View(vm);
        }

        public IActionResult Crear()
        {
            CargarViewBagsDeFormulario();
            var modelo = new InspeccionCalidad
            {
                FechaInspeccion = DateTime.Now,
                Resultado = "Aprobado",
                TipoDefecto = "Ninguno"
            };
            return View(modelo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Crear(InspeccionCalidad inspeccion)
        {
            if (ModelState.IsValid)
            {
                var (exito, mensaje) = _repositorio.Agregar(inspeccion);
                if (exito)
                {
                    TempData["Mensaje"] = mensaje;
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError(string.Empty, mensaje);
            }

            CargarViewBagsDeFormulario();
            return View(inspeccion);
        }

        public IActionResult Editar(int id)
        {
            var inspeccion = _repositorio.ObtenerPorId(id);
            if (inspeccion is null) return NotFound();

            CargarViewBagsDeFormulario();
            return View(inspeccion);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Editar(int id, InspeccionCalidad inspeccion)
        {
            if (id != inspeccion.Id) return BadRequest();

            if (ModelState.IsValid)
            {
                var (exito, mensaje) = _repositorio.Actualizar(inspeccion);
                if (exito)
                {
                    TempData["Mensaje"] = mensaje;
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError(string.Empty, mensaje);
            }

            CargarViewBagsDeFormulario();
            return View(inspeccion);
        }

        public IActionResult Eliminar(int id)
        {
            var inspeccion = _repositorio.ObtenerPorId(id);
            if (inspeccion is null) return NotFound();
            return View(inspeccion);
        }

        [HttpPost, ActionName("Eliminar")]
        [ValidateAntiForgeryToken]
        public IActionResult EliminarConfirmado(int id)
        {
            var (exito, mensaje) = _repositorio.Eliminar(id);
            TempData[exito ? "Mensaje" : "Error"] = mensaje;
            return RedirectToAction(nameof(Index));
        }

        private void CargarViewBagsDeApoyo()
        {
            ViewBag.Productos = _repositorio.ObtenerProductos();
            ViewBag.Inspectores = _repositorio.ObtenerInspectores();
            ViewBag.Resultados = CalidadRepositorio.Resultados;
        }

        private void CargarViewBagsDeFormulario()
        {
            ViewBag.Inspectores = _repositorio.ObtenerInspectores();
            ViewBag.Productos = _repositorio.ObtenerProductos();
            ViewBag.TiposDefecto = CalidadRepositorio.TiposDefecto;
            ViewBag.Resultados = CalidadRepositorio.Resultados;
        }
    }
}
