namespace Sistema_de_control_de_clidad.Models.ViewModels
{
    public class DashboardCalidaModel
    {
        public int TotalInspecciones { get; set; }
        public int TotalAprobadas { get; set; }
        public int TotalRechazadas { get; set; }
        public double TasaAprobacionGlobal { get; set; }
        public double PromedioDefectos { get; set; }
        public string InspectorLider { get; set; } = "N/A";
        public string ProductoFocoAlerta { get; set; } = "N/A";
        public List<InspeccionCalidad> UltimasInspecciones { get; set; } = new();
        public DateTime FechaServidor { get; set; } = DateTime.Now;
    }
}
