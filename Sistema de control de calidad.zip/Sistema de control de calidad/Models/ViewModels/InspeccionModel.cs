namespace Sistema_de_control_de_clidad.Models.ViewModels
{
    public class InspeccionModel
    {
        public InspeccionCalidad Inspeccion { get; set; } = new();
        public double PorcentajeDefectos { get; set; }
        public string NivelCalidad { get; set; } = string.Empty;
    }
}
