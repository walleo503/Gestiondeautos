using System.ComponentModel.DataAnnotations;

namespace Sistema_de_control_de_clidad.Models
{
    public class InspeccionCalidad
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El número de inspección es obligatorio.")]
        [Display(Name = "Número de Inspección")]
        [StringLength(20, ErrorMessage = "Máximo 20 caracteres.")]
        public string NumeroInspeccion { get; set; } = string.Empty;

        [Required(ErrorMessage = "El lote es obligatorio.")]
        [Display(Name = "Lote")]
        public string Lote { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe seleccionar un producto.")]
        [Display(Name = "Producto")]
        public string Producto { get; set; } = string.Empty;

        [Required(ErrorMessage = "Debe seleccionar un inspector.")]
        [Display(Name = "Inspector")]
        public string Inspector { get; set; } = string.Empty;

        [Required(ErrorMessage = "La cantidad inspeccionada es obligatoria.")]
        [Range(1, 1000000, ErrorMessage = "Debe ser un número mayor a 0.")]
        [Display(Name = "Cantidad Inspeccionada")]
        public int CantidadInspeccionada { get; set; }

        [Required(ErrorMessage = "La cantidad defectuosa es obligatoria.")]
        [Range(0, 1000000, ErrorMessage = "No puede ser negativa.")]
        [Display(Name = "Cantidad Defectuosa")]
        public int CantidadDefectuosa { get; set; }

        [Required]
        [Display(Name = "Resultado")]
        public string Resultado { get; set; } = "Aprobado";

        [Display(Name = "Tipo de Defecto")]
        public string TipoDefecto { get; set; } = "Ninguno";

        [Required]
        [Display(Name = "Fecha de Inspección")]
        [DataType(DataType.Date)]
        public DateTime FechaInspeccion { get; set; } = DateTime.Now;
    }
}
