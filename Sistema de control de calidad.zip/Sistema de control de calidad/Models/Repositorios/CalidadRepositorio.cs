namespace Sistema_de_control_de_clidad.Models.Repositorios
{
    public class CalidadRepositorio
    {
        private readonly List<InspeccionCalidad> _inspecciones = new();
        private int _siguienteId = 1;

        public const double LimiteMaximoDefectos = 5.0;

        public static readonly List<string> TiposDefecto = new()
        {
            "Ninguno", "Dimensional", "Estético", "Funcional", "Eléctrico", "Estructural", "Empaque"
        };

        public static readonly List<string> Resultados = new() { "Aprobado", "Rechazado" };

        public static readonly List<string> CatalogoProductos = new()
        {
            "Motor Eléctrico X1", "Panel Solar S200", "Válvula Hidráulica V12",
            "Sensor de Temperatura T5", "Batería LiFePO4 48V", "Engranaje Industrial G7"
        };

        public static readonly List<string> CatalogoInspectores = new()
        {
            "María Gómez", "Carlos Pérez", "Ana Martínez", "Luis Rodríguez", "Sofía Hernández"
        };

        public CalidadRepositorio()
        {
            Sembrar();
        }

        public List<InspeccionCalidad> ObtenerTodas()
            => _inspecciones.OrderByDescending(i => i.FechaInspeccion).ThenByDescending(i => i.Id).ToList();

        public InspeccionCalidad? ObtenerPorId(int id)
            => _inspecciones.FirstOrDefault(i => i.Id == id);

        public List<InspeccionCalidad> Buscar(string? texto)
        {
            if (string.IsNullOrWhiteSpace(texto)) return ObtenerTodas();
            texto = texto.Trim().ToLowerInvariant();
            return _inspecciones.Where(i =>
                    i.NumeroInspeccion.ToLowerInvariant().Contains(texto) ||
                    i.Lote.ToLowerInvariant().Contains(texto) ||
                    i.Producto.ToLowerInvariant().Contains(texto) ||
                    i.Inspector.ToLowerInvariant().Contains(texto))
                .OrderByDescending(i => i.FechaInspeccion)
                .ToList();
        }

        public List<InspeccionCalidad> ObtenerAprobadas()
            => _inspecciones.Where(i => i.Resultado == "Aprobado").ToList();

        public List<InspeccionCalidad> ObtenerRechazadas()
            => _inspecciones.Where(i => i.Resultado == "Rechazado").ToList();

        public List<InspeccionCalidad> Filtrar(string? producto, string? inspector, string? resultado)
        {
            var query = _inspecciones.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(producto))
                query = query.Where(i => i.Producto == producto);

            if (!string.IsNullOrWhiteSpace(inspector))
                query = query.Where(i => i.Inspector == inspector);

            if (!string.IsNullOrWhiteSpace(resultado))
                query = query.Where(i => i.Resultado == resultado);

            return query.OrderByDescending(i => i.FechaInspeccion).ToList();
        }

        public List<string> ObtenerProductos() => CatalogoProductos;

        public List<string> ObtenerInspectores() => CatalogoInspectores;

        public double CalcularPorcentajeDefectos(InspeccionCalidad inspeccion)
        {
            if (inspeccion.CantidadInspeccionada <= 0) return 0;
            return Math.Round((double)inspeccion.CantidadDefectuosa / inspeccion.CantidadInspeccionada * 100, 2);
        }

        public string ObtenerNivelCalidad(double porcentajeDefectos)
        {
            if (porcentajeDefectos <= 1) return "Excelente";
            if (porcentajeDefectos <= 3) return "Bueno";
            if (porcentajeDefectos <= 5) return "Regular";
            return "Crítico";
        }

        public bool ExisteNumeroInspeccion(string numero, int idExcluir = 0)
            => _inspecciones.Any(i =>
                i.NumeroInspeccion.Equals(numero, StringComparison.OrdinalIgnoreCase) && i.Id != idExcluir);

        public (bool Exito, string Mensaje) Agregar(InspeccionCalidad inspeccion)
        {
            var validacion = ValidarReglasDeNegocio(inspeccion, esNueva: true);
            if (!validacion.Exito) return validacion;

            inspeccion.Id = _siguienteId++;
            _inspecciones.Add(inspeccion);
            return (true, "Inspección registrada correctamente.");
        }

        public (bool Exito, string Mensaje) Actualizar(InspeccionCalidad inspeccion)
        {
            var existente = ObtenerPorId(inspeccion.Id);
            if (existente is null) return (false, "No se encontró la inspección a actualizar.");

            var validacion = ValidarReglasDeNegocio(inspeccion, esNueva: false);
            if (!validacion.Exito) return validacion;

            existente.NumeroInspeccion = inspeccion.NumeroInspeccion;
            existente.Lote = inspeccion.Lote;
            existente.Producto = inspeccion.Producto;
            existente.Inspector = inspeccion.Inspector;
            existente.CantidadInspeccionada = inspeccion.CantidadInspeccionada;
            existente.CantidadDefectuosa = inspeccion.CantidadDefectuosa;
            existente.Resultado = inspeccion.Resultado;
            existente.TipoDefecto = inspeccion.TipoDefecto;
            existente.FechaInspeccion = inspeccion.FechaInspeccion;

            return (true, "Inspección actualizada correctamente.");
        }

        public (bool Exito, string Mensaje) Eliminar(int id)
        {
            var inspeccion = ObtenerPorId(id);
            if (inspeccion is null) return (false, "No se encontró la inspección.");

            if (inspeccion.Resultado == "Aprobado")
                return (false, "No se puede eliminar una inspección con resultado 'Aprobado'.");

            _inspecciones.Remove(inspeccion);
            return (true, "Inspección eliminada correctamente.");
        }

        private (bool Exito, string Mensaje) ValidarReglasDeNegocio(InspeccionCalidad inspeccion, bool esNueva)
        {
            if (inspeccion.CantidadDefectuosa > inspeccion.CantidadInspeccionada)
                return (false, "La cantidad defectuosa no puede ser mayor a la cantidad inspeccionada.");

            int idExcluir = esNueva ? 0 : inspeccion.Id;
            if (ExisteNumeroInspeccion(inspeccion.NumeroInspeccion, idExcluir))
                return (false, "Ya existe una inspección registrada con ese número. Debe ser único.");

            double porcentaje = CalcularPorcentajeDefectos(inspeccion);
            if (inspeccion.Resultado == "Aprobado" && porcentaje > LimiteMaximoDefectos)
                return (false,
                    $"No es posible aprobar este lote: el porcentaje de defectos ({porcentaje}%) " +
                    $"supera el máximo permitido de {LimiteMaximoDefectos}%. El resultado debe ser 'Rechazado'.");

            return (true, string.Empty);
        }

        private void Sembrar()
        {
            var productos = CatalogoProductos;
            var inspectores = CatalogoInspectores;
            var tipos = TiposDefecto;

            var random = new Random(2026);

            for (int i = 1; i <= 35; i++)
            {
                int inspeccionadas = random.Next(50, 500);
                double porcentajeObjetivo = random.NextDouble() < 0.75
                    ? random.NextDouble() * 4.5
                    : 4.5 + random.NextDouble() * 10;

                int defectuosas = (int)Math.Round(inspeccionadas * porcentajeObjetivo / 100.0);
                defectuosas = Math.Min(defectuosas, inspeccionadas);

                double porcentajeReal = inspeccionadas == 0 ? 0 : Math.Round((double)defectuosas / inspeccionadas * 100, 2);
                string resultado = porcentajeReal <= LimiteMaximoDefectos ? "Aprobado" : "Rechazado";
                string tipoDefecto = defectuosas == 0 ? "Ninguno" : tipos[random.Next(1, tipos.Count)];

                _inspecciones.Add(new InspeccionCalidad
                {
                    Id = _siguienteId++,
                    NumeroInspeccion = $"INS-{2026000 + i}",
                    Lote = $"LOTE-{random.Next(1000, 9999)}",
                    Producto = productos[random.Next(productos.Count)],
                    Inspector = inspectores[random.Next(inspectores.Count)],
                    CantidadInspeccionada = inspeccionadas,
                    CantidadDefectuosa = defectuosas,
                    Resultado = resultado,
                    TipoDefecto = tipoDefecto,
                    FechaInspeccion = DateTime.Now.AddDays(-random.Next(0, 60)).AddHours(-random.Next(0, 23))
                });
            }
        }
    }
}
